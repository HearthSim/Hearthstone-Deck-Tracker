namespace HearthMirror.Objects
{
	public class BattleTag
	{
		public string Name { get; set; }
		public int Number { get; set; }
	}
}