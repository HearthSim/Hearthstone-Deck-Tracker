﻿namespace HearthMirror.Objects
{
	public class SetFilterItem
	{
		public bool IsAllStandard { get; set; }
		public bool IsWild { get; set; }
	}
}