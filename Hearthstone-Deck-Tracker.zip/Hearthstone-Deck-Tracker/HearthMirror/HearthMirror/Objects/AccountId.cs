namespace HearthMirror.Objects
{
	public class AccountId
	{
		public ulong Hi { get; set; }
		public ulong Lo { get; set; }
	}
}
