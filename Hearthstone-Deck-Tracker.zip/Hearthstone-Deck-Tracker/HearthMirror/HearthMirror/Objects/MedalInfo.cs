﻿namespace HearthMirror.Objects
{
	public class MedalInfo
	{
		public MedalInfoData Standard { get; set; }
		public MedalInfoData Wild { get; set; }
	}
}
