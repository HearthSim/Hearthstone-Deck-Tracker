namespace HearthMirror.Enums
{
	public enum UI_WINDOW
	{
		NONE,
		GENERAL_STORE,
		ARENA_STORE,
		QUEST_LOG,
	}
}