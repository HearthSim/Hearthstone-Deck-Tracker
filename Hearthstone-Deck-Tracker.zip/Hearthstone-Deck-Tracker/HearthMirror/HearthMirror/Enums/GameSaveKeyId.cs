﻿namespace HearthMirror.Enums
{
	public enum GameSaveKeyId
	{
		ADVENTURE_DATA_LOOT = 24
	}
}