﻿namespace HearthMirror.Enums
{
	public enum Side
	{
		NEUTRAL,
		FRIENDLY,
		OPPOSING
	}
}