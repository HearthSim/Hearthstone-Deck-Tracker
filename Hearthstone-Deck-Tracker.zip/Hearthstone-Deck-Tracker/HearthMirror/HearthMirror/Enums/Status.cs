﻿namespace HearthMirror.Enums
{
	public enum MirrorStatus
	{
		Ok,
		ProcNotFound,
		Error
	}
}