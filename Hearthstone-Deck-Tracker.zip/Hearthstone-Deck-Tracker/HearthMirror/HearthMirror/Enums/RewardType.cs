namespace HearthMirror.Enums
{
	public enum RewardType
	{
		ARCANE_DUST,
		BOOSTER_PACK,
		CARD,
		CARD_BACK,
		CRAFTABLE_CARD,
		FORGE_TICKET,
		GOLD,
		MOUNT,
		CLASS_CHALLENGE
	}
}