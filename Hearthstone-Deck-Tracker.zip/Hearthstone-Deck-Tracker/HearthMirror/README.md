# HearthMirror

[![Build status](https://ci.appveyor.com/api/projects/status/0ltedeck99oh8t9b/branch/master?svg=true)](https://ci.appveyor.com/project/Epix37/hearthmirror/branch/master)


## License

Copyright © HearthSim. All Rights Reserved.
