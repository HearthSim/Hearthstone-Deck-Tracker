namespace Hearthstone_Deck_Tracker.Enums
{
	public enum DisplayMode
	{
		[LocDescription("Enum_DisplayMode_Always")]
		Always,
		[LocDescription("Enum_DisplayMode_Auto")]
		Auto,
		[LocDescription("Enum_DisplayMode_Never")]
		Never
	}
}
