namespace Hearthstone_Deck_Tracker.Enums
{
	public enum YesNo
	{
		[LocDescription("Enum_YesNo_Yes")]
		Yes,
		[LocDescription("Enum_YesNo_No")]
		No
	}

	public enum AllYesNo
	{
		[LocDescription("Enum_YesNoAll_All")]
		All,
		[LocDescription("Enum_YesNo_Yes")]
		Yes,
		[LocDescription("Enum_YesNo_No")]
		No
	}
}
