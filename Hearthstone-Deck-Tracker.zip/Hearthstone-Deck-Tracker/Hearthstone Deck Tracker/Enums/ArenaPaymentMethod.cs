﻿namespace Hearthstone_Deck_Tracker.Enums
{
	public enum ArenaPaymentMethod
	{
		Unknown,
		Gold,
		Money
	}
}
