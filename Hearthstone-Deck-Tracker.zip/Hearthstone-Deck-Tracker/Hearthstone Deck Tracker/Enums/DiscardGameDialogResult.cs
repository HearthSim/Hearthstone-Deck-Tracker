﻿namespace Hearthstone_Deck_Tracker.Enums
{
	public enum DiscardGameDialogResult
	{
		Discard,
		Keep,
		MoveToOther
	}
}
