namespace Hearthstone_Deck_Tracker.Enums
{
	public enum TagFilerOperation
	{
		[LocDescription("Enum_TagFilterOperation_And")]
		And,
		[LocDescription("Enum_TagFilterOperation_Or")]
		Or
	}
}
