namespace Hearthstone_Deck_Tracker.Enums
{
	public enum DeckLayout
	{
		[LocDescription("Enum_DeckLayout_Layout1")]
		Layout1,
		[LocDescription("Enum_DeckLayout_Layout2")]
		Layout2,
		[LocDescription("Enum_DeckLayout_Legacy")]
		Legacy
	}
}
