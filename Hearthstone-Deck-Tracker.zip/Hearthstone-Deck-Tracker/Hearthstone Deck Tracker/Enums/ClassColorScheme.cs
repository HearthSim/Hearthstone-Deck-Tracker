namespace Hearthstone_Deck_Tracker.Enums
{
	public enum ClassColorScheme
	{
		[LocDescription("Enum_ClassColorScheme_Classic")]
		Classic,
		[LocDescription("Enum_ClassColorScheme_Alternative")]
		HearthStats
	}
}
