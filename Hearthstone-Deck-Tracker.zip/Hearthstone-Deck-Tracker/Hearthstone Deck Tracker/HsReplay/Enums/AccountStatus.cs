namespace Hearthstone_Deck_Tracker.HsReplay.Enums
{
	public enum AccountStatus
	{
		Anonymous,
		Registered
	}
}
