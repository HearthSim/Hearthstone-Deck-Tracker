﻿#region

using System.Windows.Controls;

#endregion

namespace Hearthstone_Deck_Tracker.Controls
{
	/// <summary>
	/// Interaction logic for CardToolTipControl.xaml
	/// </summary>
	public partial class CardToolTipControl : UserControl
	{
		public CardToolTipControl()
		{
			InitializeComponent();
		}
	}
}
