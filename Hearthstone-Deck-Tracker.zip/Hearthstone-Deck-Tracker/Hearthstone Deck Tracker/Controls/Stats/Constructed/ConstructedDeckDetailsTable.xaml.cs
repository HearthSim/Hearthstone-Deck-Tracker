﻿using System.Windows.Controls;

namespace Hearthstone_Deck_Tracker.Controls.Stats.Constructed
{
	/// <summary>
	/// Interaction logic for ConstructedDeckDetailsTable.xaml
	/// </summary>
	public partial class ConstructedDeckDetailsTable : UserControl
	{
		public ConstructedDeckDetailsTable()
		{
			InitializeComponent();
		}
	}
}
