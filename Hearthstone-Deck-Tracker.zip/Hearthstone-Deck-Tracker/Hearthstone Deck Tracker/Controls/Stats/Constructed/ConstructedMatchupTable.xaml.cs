﻿using System.Windows.Controls;

namespace Hearthstone_Deck_Tracker.Controls.Stats.Constructed
{
	/// <summary>
	/// Interaction logic for ConstructedMatchupTable.xaml
	/// </summary>
	public partial class ConstructedMatchupTable : UserControl
	{
		public ConstructedMatchupTable()
		{
			InitializeComponent();
		}
	}
}
