﻿#region

using System.Windows.Controls;

#endregion

namespace Hearthstone_Deck_Tracker.Controls.Stats.Arena
{
	/// <summary>
	/// Interaction logic for ArensStatsSummaryClasses.xaml
	/// </summary>
	public partial class ArensStatsSummaryClasses : UserControl
	{
		public ArensStatsSummaryClasses()
		{
			InitializeComponent();
		}
	}
}
