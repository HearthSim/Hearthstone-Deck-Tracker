﻿#region

using System.Windows.Controls;

#endregion

namespace Hearthstone_Deck_Tracker.Controls.Stats.Arena.Charts
{
	/// <summary>
	/// Interaction logic for ChartWins.xaml
	/// </summary>
	public partial class ChartWins : UserControl
	{
		public ChartWins()
		{
			InitializeComponent();
		}
	}
}
