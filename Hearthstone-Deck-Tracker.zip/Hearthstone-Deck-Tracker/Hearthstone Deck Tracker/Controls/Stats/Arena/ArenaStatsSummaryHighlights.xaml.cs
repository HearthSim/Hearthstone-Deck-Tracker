﻿#region

using System.Windows.Controls;

#endregion

namespace Hearthstone_Deck_Tracker.Controls.Stats.Arena
{
	/// <summary>
	/// Interaction logic for ArenaStatsSummaryHighlights.xaml
	/// </summary>
	public partial class ArenaStatsSummaryHighlights : UserControl
	{
		public ArenaStatsSummaryHighlights()
		{
			InitializeComponent();
		}
	}
}
