﻿namespace Hearthstone_Deck_Tracker.Controls.DeckPicker.DeckPickerItemLayouts
{
	/// <summary>
	/// Interaction logic for DeckPickerItemLayoutMinimal.xaml
	/// </summary>
	public partial class DeckPickerItemLayoutMinimal
	{
		public DeckPickerItemLayoutMinimal()
		{
			InitializeComponent();
		}
	}
}
