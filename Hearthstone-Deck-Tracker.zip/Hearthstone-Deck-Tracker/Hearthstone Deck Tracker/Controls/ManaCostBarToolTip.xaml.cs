﻿namespace Hearthstone_Deck_Tracker.Controls
{
	/// <summary>
	/// Interaction logic for ManaCostBarToolTip.xaml
	/// </summary>
	public partial class ManaCostBarToolTip
	{
		public ManaCostBarToolTip()
		{
			InitializeComponent();
		}
	}
}
