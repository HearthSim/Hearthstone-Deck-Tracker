﻿namespace Hearthstone_Deck_Tracker.Controls
{
	/// <summary>
	/// Interaction logic for HearthstoneTextBlock.xaml
	/// </summary>
	public partial class HearthstoneTextBlock
	{
		public HearthstoneTextBlock()
		{
			InitializeComponent();
		}
	}
}
