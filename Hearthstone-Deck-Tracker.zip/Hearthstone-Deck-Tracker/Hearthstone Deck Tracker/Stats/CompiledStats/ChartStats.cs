#region

using System.Windows.Media;

#endregion

namespace Hearthstone_Deck_Tracker.Stats.CompiledStats
{
	public class ChartStats
	{
		public string Name { get; set; }
		public double Value { get; set; }
		public Brush Brush { get; set; }
	}
}
