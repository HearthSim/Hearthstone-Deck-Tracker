#region

using System;
using System.Text.RegularExpressions;
using System.Windows;
using Hearthstone_Deck_Tracker.Utility.Analytics;

#endregion

namespace Hearthstone_Deck_Tracker.Utility
{
	public class ConfigWrapper
	{
		public static bool CardDbIncludeWildOnlyCards
		{
			get => Config.Instance.CardDbIncludeWildOnlyCards;
			set
			{
				Config.Instance.CardDbIncludeWildOnlyCards = value;
				Config.Save();
			}
		}

		public static bool ArenaStatsShowLegends
		{
			get => Config.Instance.ArenaStatsShowLegends;
			set
			{
				Config.Instance.ArenaStatsShowLegends = value;
				Config.Save();
			}
		}

		public static DateTime? ArenaStatsTimeFrameCustomStart
		{
			get => Config.Instance.ArenaStatsTimeFrameCustomStart;
			set
			{
				Config.Instance.ArenaStatsTimeFrameCustomStart = value;
				Config.Save();
			}
		}

		public static DateTime? ArenaStatsTimeFrameCustomEnd
		{
			get => Config.Instance.ArenaStatsTimeFrameCustomEnd;
			set
			{
				Config.Instance.ArenaStatsTimeFrameCustomEnd = value;
				Config.Save();
			}
		}

		public static bool ArenaStatsIncludeArchived
		{
			get => Config.Instance.ArenaStatsIncludeArchived;
			set
			{
				Config.Instance.ArenaStatsIncludeArchived = value;
				Config.Save();
			}
		}

		public static bool ArenaRewardDialog
		{
			get => Config.Instance.ArenaRewardDialog;
			set
			{
				Config.Instance.ArenaRewardDialog = value;
				Config.Save();
			}
		}

		public static int StatsWindowHeight
		{
			get => Config.Instance.StatsWindowHeight;
			set
			{
				Config.Instance.StatsWindowHeight = value;
				Config.Save();
			}
		}

		public static int StatsWindowWidth
		{
			get => Config.Instance.StatsWindowWidth;
			set
			{
				Config.Instance.StatsWindowWidth = value;
				Config.Save();
			}
		}

		public static bool ArenaSummaryChartsExpanded
		{
			get => Config.Instance.ArenaSummaryChartsExpanded;
			set
			{
				Config.Instance.ArenaSummaryChartsExpanded = value;
				Config.Save();
			}
		}

		public static bool ConstructedSummaryChartsExpanded
		{
			get => Config.Instance.ConstructedSummaryChartsExpanded;
			set
			{
				Config.Instance.ConstructedSummaryChartsExpanded = value;
				Config.Save();
			}
		}

		public static bool DeckPickerWildIncludesStandard
		{
			get => Config.Instance.DeckPickerWildIncludesStandard;
			set
			{
				Config.Instance.DeckPickerWildIncludesStandard = value;
				Config.Save();
			}
		}

		public static bool ConstructedStatsIncludeArchived
		{
			get => Config.Instance.ConstructedStatsIncludeArchived;
			set
			{
				Config.Instance.ConstructedStatsIncludeArchived = value;
				Config.Save();
			}
		}


		public static bool ConstructedStatsAsPercent
		{
			get => Config.Instance.ConstructedStatsAsPercent;
			set
			{
				Config.Instance.ConstructedStatsAsPercent = value;
				Config.Save();
			}
		}
		public static DateTime? ConstructedStatsTimeFrameCustomStart
		{
			get => Config.Instance.ConstructedStatsTimeFrameCustomStart;
			set
			{
				Config.Instance.ConstructedStatsTimeFrameCustomStart = value;
				Config.Save();
			}
		}

		public static DateTime? ConstructedStatsTimeFrameCustomEnd
		{
			get => Config.Instance.ConstructedStatsTimeFrameCustomEnd;
			set
			{
				Config.Instance.ConstructedStatsTimeFrameCustomEnd = value;
				Config.Save();
			}
		}

		public static bool StatsAutoRefresh
		{
			get => Config.Instance.StatsAutoRefresh;
			set
			{
				Config.Instance.StatsAutoRefresh = value;
				Config.Save();
			}
		}

		public static bool ConstructedStatsApplyTagFilters
		{
			get => Config.Instance.ConstructedStatsApplyTagFilters;
			set
			{
				Config.Instance.ConstructedStatsApplyTagFilters = value;
				Config.Save();
			}
		}

		public static bool HsReplayAutoUpload
		{
			get => Config.Instance.HsReplayAutoUpload;
			set
			{
				Config.Instance.HsReplayAutoUpload = value;
				Config.Save();
				Influx.OnHsReplayAutoUploadChanged(value);
			}
		}

		public static bool HsReplayUploadRanked
		{
			get => Config.Instance.HsReplayUploadRanked;
			set
			{
				Config.Instance.HsReplayUploadRanked = value;
				Config.Save();
			}
		}

		public static bool HsReplayUploadCasual
		{
			get => Config.Instance.HsReplayUploadCasual;
			set
			{
				Config.Instance.HsReplayUploadCasual = value;
				Config.Save();
			}
		}

		public static bool HsReplayUploadArena
		{
			get => Config.Instance.HsReplayUploadArena;
			set
			{
				Config.Instance.HsReplayUploadArena = value;
				Config.Save();
			}
		}

		public static bool HsReplayUploadBrawl
		{
			get => Config.Instance.HsReplayUploadBrawl;
			set
			{
				Config.Instance.HsReplayUploadBrawl = value;
				Config.Save();
			}
		}

		public static bool HsReplayUploadFriendly
		{
			get => Config.Instance.HsReplayUploadFriendly;
			set
			{
				Config.Instance.HsReplayUploadFriendly = value;
				Config.Save();
			}
		}

		public static bool HsReplayUploadPractice
		{
			get => Config.Instance.HsReplayUploadPractice;
			set
			{
				Config.Instance.HsReplayUploadPractice = value;
				Config.Save();
			}
		}

		public static bool HsReplayUploadSpectator
		{
			get => Config.Instance.HsReplayUploadSpectator;
			set
			{
				Config.Instance.HsReplayUploadSpectator = value;
				Config.Save();
			}
		}

		public static Visibility ShowLastPlayedDateOnDeckVisibility => Config.Instance.ShowLastPlayedDateOnDeck ? Visibility.Visible : Visibility.Collapsed;

		public static Visibility UseButtonVisiblity => Config.Instance.AutoUseDeck ? Visibility.Collapsed : Visibility.Visible;

		public static bool ConstructedStatsActiveDeckOnly
		{
			get
			{
				if(DeckList.Instance.ActiveDeck != null)
					return Config.Instance.ConstructedStatsActiveDeckOnly;
				if(Config.Instance.ConstructedStatsActiveDeckOnly)
				{
					Config.Instance.ConstructedStatsActiveDeckOnly = false;
					Config.Save();
				}
				return Config.Instance.ConstructedStatsActiveDeckOnly;
			}
			set
			{
				var newValue = DeckList.Instance.ActiveDeck != null && value;
				if(Config.Instance.ConstructedStatsActiveDeckOnly == newValue)
					return;
				Config.Instance.ConstructedStatsActiveDeckOnly = newValue;
				Config.Save();
			}
		}

		public static string ConstructedStatsRankFilterMin
		{
			get => Config.Instance.ConstructedStatsRankFilterMin;
			set
			{
				Config.Instance.ConstructedStatsRankFilterMin = ValidateRank(value, false);
				Config.Save();
			}
		}
		public static string ConstructedStatsRankFilterMax
		{
			get => Config.Instance.ConstructedStatsRankFilterMax;
			set
			{
				Config.Instance.ConstructedStatsRankFilterMax = ValidateRank(value, true);
				Config.Save();
			}
		}

		public static string ConstructedStatsCustomSeasonMin
		{
			get => Config.Instance.ConstructedStatsCustomSeasonMin.ToString();
			set
			{
				Config.Instance.ConstructedStatsCustomSeasonMin = ValidateSeason(value, false) ?? 1;
				Config.Save();
			}
		}
		public static string ConstructedStatsCustomSeasonMax
		{
			get => Config.Instance.ConstructedStatsCustomSeasonMax.ToString();
			set
			{
				Config.Instance.ConstructedStatsCustomSeasonMax = ValidateSeason(value, true);
				Config.Save();
			}
		}

		public static string ArenaStatsCustomSeasonMin
		{
			get => Config.Instance.ArenaStatsCustomSeasonMin.ToString();
			set
			{
				Config.Instance.ArenaStatsCustomSeasonMin = ValidateSeason(value, false) ?? 1;
				Config.Save();
			}
		}
		public static string ArenaStatsCustomSeasonMax
		{
			get => Config.Instance.ArenaStatsCustomSeasonMax.ToString();
			set
			{
				Config.Instance.ArenaStatsCustomSeasonMax = ValidateSeason(value, true);
				Config.Save();
			}
		}

		public bool HsReplayShareToast
		{
			get => Config.Instance.ShowReplayShareToast;
			set
			{
				Config.Instance.ShowReplayShareToast = value;
				Config.Save();
			}
		}

		public bool CheckForDevUpdates
		{
			get => Config.Instance.CheckForDevUpdates;
			set
			{
				Config.Instance.CheckForDevUpdates = value;
				Config.Instance.AllowDevUpdates = null;
				Config.Save();
			}
		}

		public bool WindowCardToolTips => Config.Instance.WindowCardToolTips;

		private static int? ValidateSeason(string value, bool allowEmpty)
		{
			if(allowEmpty && string.IsNullOrEmpty(value))
				return null;
			if(!int.TryParse(value, out var season))
				throw new ApplicationException("Invalid season");
			if(season < 1)
				throw new ApplicationException("Invalid season. Minimum value: 1");
			var currentSeaon = Helper.CurrentSeason;
			if(season > currentSeaon)
				throw new ApplicationException("Invalid season. Current season: " + currentSeaon);
			return season;
		}

		private static string ValidateRank(string value, bool allowEmpty)
		{
			if(allowEmpty && string.IsNullOrEmpty(value))
				return value;
			var match = Regex.Match(value, @"(?<legend>([lL]))?(?<rank>(\d+))");
			if(!match.Success)
				throw new ApplicationException("Invalid rank");
			var legend = match.Groups["legend"].Success;
			if(int.TryParse(match.Groups["rank"].Value, out var rank))
			{
				if(!legend && rank > 25)
					throw new ApplicationException("Rank can not be higher than 25");
				if(rank < 1)
					throw new ApplicationException("Rank can not be lower than 1");
			}
			else
				throw new ApplicationException("Invalid rank");
			return (legend ? "L" : "") + rank;
		}
	}
}
