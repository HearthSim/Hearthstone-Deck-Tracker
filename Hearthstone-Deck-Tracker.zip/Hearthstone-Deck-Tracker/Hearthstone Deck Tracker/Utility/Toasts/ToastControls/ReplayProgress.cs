namespace Hearthstone_Deck_Tracker.Utility.Toasts.ToastControls
{
	public enum ReplayProgress
	{
		Uploading,
		Complete,
		Error
	}
}
