﻿using Hearthstone_Deck_Tracker.Hearthstone;

namespace Hearthstone_Deck_Tracker.Utility.Themes
{
	public class DefaultBarImageBuilder : CardBarImageBuilder
	{
		public DefaultBarImageBuilder(Card card, string dir) : base(card, dir)
		{
		}
	}
}
