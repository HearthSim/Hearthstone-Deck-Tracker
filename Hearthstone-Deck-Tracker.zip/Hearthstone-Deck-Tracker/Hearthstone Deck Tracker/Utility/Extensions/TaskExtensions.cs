﻿using System.Threading.Tasks;

namespace Hearthstone_Deck_Tracker.Utility.Extensions
{
	public static class TaskExtensions
	{
		public static void Forget(this Task task)
		{
		}
	}
}
