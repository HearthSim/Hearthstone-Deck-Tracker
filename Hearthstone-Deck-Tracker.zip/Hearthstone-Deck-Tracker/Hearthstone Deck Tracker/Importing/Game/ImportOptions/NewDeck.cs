namespace Hearthstone_Deck_Tracker.Importing.Game.ImportOptions
{
	public class NewDeck : IImportOption
	{
		public string DisplayName => "New Deck";
	}
}
