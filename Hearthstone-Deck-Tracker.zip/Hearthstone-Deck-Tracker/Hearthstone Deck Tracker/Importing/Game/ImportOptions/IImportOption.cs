namespace Hearthstone_Deck_Tracker.Importing.Game.ImportOptions
{
	public interface IImportOption
	{
		string DisplayName { get; }
	}
}
