﻿#region

using System.Windows.Controls;

#endregion

namespace Hearthstone_Deck_Tracker.Controls.Error
{
	/// <summary>
	/// Interaction logic for ErrorList.xaml
	/// </summary>
	public partial class ErrorList : UserControl
	{
		public ErrorList()
		{
			InitializeComponent();
		}
	}
}
